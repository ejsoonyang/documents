var ranran=0;
var newran = 0;

var ranvii=1;
var newvii = 1;

var ranshi=1;
var newshi = 1;

function lic() {
	var huga;
	if(window.XMLHttpRequest) {
		huga=new XMLHttpRequest();
		huga.onreadystatechange=function() {
		if (huga.readyState==4) {
		//if (huga.readyState==4 && huga.status==200) {
			document.getElementById("lic").innerHTML=huga.responseText+"[lenght]"+huga.responseText.length+"["+huga.readyState+"]"+"{"+huga.status+"}"+huga.responseText.split("\n")[0]+huga.responseText.split("\n")[0].length+huga.responseText.split("\n")[2];
			}
		}
		huga.open("GET","giki?wuhu=gi",true);
		huga.send();
	}
}

function gagachui() {
	var txt = "";
	while(ranran==newran){
		newran=Math.floor(Math.random()*5+1);
	}
	ranran=newran;
	txt=String(newran);
	txt="jpg/"+txt+".jpg"
	document.getElementById("gaimg").src=txt;
}

function dagachui() {
	var txt = "";
	while(ranvii==newvii){
		newvii=Math.floor(Math.random()*5+1);
	}
	txt = "ryga"+String(newvii);
	document.getElementById(txt).style.visibility="visible";
	txt = "ryga"+String(ranvii);
	document.getElementById(txt).style.visibility="hidden";
	ranvii=newvii;
}

function dgar() {
	daga=setInterval("dagachui()",300);
}

function gary() {
	clearInterval(daga);
}

function capd() {
	var lugu=document.createElement("img");
	var lufu=document.createElement("script");
	lugu.src="html5.png";
	lufu.src="addaexe.js";
	pp=document.getElementById("guki");
	pp.appendChild(lugu);
	pp.appendChild(lufu);
}

function in_shine() {
	var txt = "";
	newshi+=1;
	if(newshi==7) {
		newshi=1;
	}
	txt = "feeling"+String(newshi);
	document.getElementById(txt).style.visibility="visible";
	txt = "feeling"+String(ranshi);
	document.getElementById(txt).style.visibility="hidden";
	ranshi=newshi;
}

function shine() {
	setInterval("in_shine()", 170);
}

function wuwa() {
	var haad = document.getElementById("wuwu");
	var wuga = [];
	var texthuhu = [];
	var i = 0;
	var huga;
	if(window.XMLHttpRequest) {
		huga=new XMLHttpRequest();
		huga.onreadystatechange=function() {
			if (huga.readyState==4) {
				i = huga.responseText.split("\n").length - 1;
				alert(huga.responseText.split("\n")[1]+String(i));
				while (i > 0) {
					wuga[i - 1] = document.createElement("a");
					texthuhu[i - 1] = document.createTextNode(huga.responseText.split("\n")[i - 1]);
					wuga[i - 1].href="guga.com"+String(i);
					//
					wuga[i - 1].appendChild(texthuhu[i - 1]);
					haad.appendChild(wuga[i - 1]);
					i -= 1;
				}
			}
		//if (xmlhttp.readyState==4 && xmlhttp.status==200) 
		}
		//huga.open("GET","giki?wuhu=gi",true);
		//huga.open("GET","../../public_html/giki?wuhu=gi",true);
		huga.open("GET","dada/giki?wuhu=gi",true);
		huga.send();
	}
}
