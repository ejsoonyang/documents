function changeIt(soso)
{
var cis=new Array("Saab","Volvo","我是真的改變了!");
document.getElementById("ci").innerHTML=cis[2];
document.getElementById("addd").innerHTML="the length of the string above is "+cis[2].length+" and soso is "+soso;
return;
}
function koko()
{
alert("window.location.pathname\n"+window.location.pathname);
alert("window.location.href\n"+window.location.href);

alert("window.location.port\n"+window.location.port);

alert("window.location.protocol\n"+window.location.protocol);

alert("window.location.hash\n"+window.location.hash);

alert("window.location.host\n"+window.location.host);

alert("window.location.search\n"+window.location.search);
}
